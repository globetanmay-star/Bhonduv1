# bhondu

Small browser tools for social visuals. Everything runs on your device; no images are uploaded.

## Setup

Requires Node.js 18 or newer.

```bash
npm install
npm run dev      # start the dev server at http://localhost:5173
npm run build    # type-check and build to dist/
npm run preview  # serve the built site locally
```

## Tools

- **Text Mockup**: message bubbles in three styles, exported as PNG (transparent or coloured background).
- **Social Tag**: username tag with light/dark theme and optional verified badge, exported as transparent PNG.
- **Stamp**: photo cut into a square, vertical, horizontal or circle stamp with a perforated edge, exported as transparent PNG.
- **Pixel Effect**: pixelate a photo with an adjustable block size, with before/after preview, exported as PNG.

## Project structure

```
src/
  App.tsx              hash-based routing (#/ and #/tools/<slug>)
  styles.css           design tokens (CSS variables) and shared styles
  lib/canvas.ts        canvas helpers: sizing, text wrapping, PNG download, image loading
  components/          Layout, ToolShell (tool page frame), ImageInput
  pages/Home.tsx       homepage: hero, searchable tool directory, how it works
  tools/registry.ts    list of tools shown on the homepage and in the nav
  tools/*.tsx          one file per tool
```

## Adding a tool

1. Create `src/tools/MyTool.tsx` with a default-exported component. Use `ToolShell` for the layout and `downloadCanvasPng` for export.
2. Add an entry to `TOOLS` in `src/tools/registry.ts`. The slug becomes the URL: `#/tools/<slug>`.

## Known limitations

- No background removal, video export, 2K/4K scaling, accounts or payments.
- Pixel Effect applies to the whole image; there is no region selection.
- Output formats are PNG only.
- Stamp has no colour tint or pattern options yet.
- Text Mockup does not wrap single words wider than the bubble.
- This version has not been run in a browser by the author of this code. Run `npm run build` and test each tool before relying on it.
