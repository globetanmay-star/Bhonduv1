import { loadImageFile } from "../lib/canvas";

interface ImageInputProps {
  label: string;
  onLoad: (img: HTMLImageElement, file: File) => void;
  onError: (message: string) => void;
}

export function ImageInput({ label, onLoad, onError }: ImageInputProps) {
  return (
    <label className="button file-input">
      {label}
      <input
        className="visually-hidden"
        type="file"
        accept="image/png,image/jpeg,image/webp,image/gif"
        onChange={(e) => {
          const file = e.target.files?.[0];
          e.target.value = "";
          if (!file) return;
          loadImageFile(file)
            .then((img) => onLoad(img, file))
            .catch((err: unknown) =>
              onError(err instanceof Error ? err.message : "Could not load that image."),
            );
        }}
      />
    </label>
  );
}
