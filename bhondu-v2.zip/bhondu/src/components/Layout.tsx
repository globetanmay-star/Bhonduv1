import type { ReactNode } from "react";
import { TOOLS } from "../tools/registry";

interface LayoutProps {
  path: string;
  children: ReactNode;
}

export function Layout({ path, children }: LayoutProps) {
  return (
    <div className="app">
      <header className="site-header">
        <a className="brand" href="#/" aria-label="bhondu home">
          <span className="brand-mark" aria-hidden="true">b</span>
          bhondu
        </a>
        <nav aria-label="Main">
          <ul className="nav-list">
            <li>
              <a href="#/" aria-current={path === "/" ? "page" : undefined}>
                Home
              </a>
            </li>
            {TOOLS.map((tool) => {
              const to = `/tools/${tool.slug}`;
              return (
                <li key={tool.slug}>
                  <a href={`#${to}`} aria-current={path === to ? "page" : undefined}>
                    {tool.name}
                  </a>
                </li>
              );
            })}
          </ul>
        </nav>
      </header>
      <main id="main">{children}</main>
      <footer className="site-footer">
        <p>bhondu: small creative tools that run in your browser.</p>
        <p>Your images stay on your device. Nothing is uploaded.</p>
      </footer>
    </div>
  );
}
