import type { ReactNode } from "react";

interface ToolShellProps {
  title: string;
  intro: string;
  controls: ReactNode;
  preview: ReactNode;
}

export function ToolShell({ title, intro, controls, preview }: ToolShellProps) {
  return (
    <div className="tool">
      <header className="tool-header">
        <h1>{title}</h1>
        <p>{intro}</p>
      </header>
      <div className="tool-layout">
        <div className="panel controls">{controls}</div>
        <div className="panel preview">{preview}</div>
      </div>
    </div>
  );
}
