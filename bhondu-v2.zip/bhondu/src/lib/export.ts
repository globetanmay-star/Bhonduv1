import { ctxOf } from "./canvas";

export type ExportSize = "hd" | "2k" | "4k";

const LONG_SIDES: Record<ExportSize, number> = { hd: 1080, "2k": 2048, "4k": 3840 };

export const EXPORT_SIZE_OPTIONS: { value: ExportSize; label: string }[] = [
  { value: "hd", label: "HD 1080" },
  { value: "2k", label: "2K 2048" },
  { value: "4k", label: "4K 3840" },
];

export function longSideOf(size: ExportSize): number {
  return LONG_SIDES[size];
}

/** Scale that takes a design drawn at the given logical long side to the export size. */
export function scaleFor(size: ExportSize, logicalLongSide: number): number {
  return LONG_SIDES[size] / logicalLongSide;
}

/** Output dimensions so the longest side equals the export size. Scales up or down. */
export function fitTo(size: ExportSize, w: number, h: number): { w: number; h: number } {
  const s = LONG_SIDES[size] / Math.max(w, h);
  return { w: Math.max(1, Math.round(w * s)), h: Math.max(1, Math.round(h * s)) };
}

export function canvasToBlob(canvas: HTMLCanvasElement): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => (blob ? resolve(blob) : reject(new Error("Could not create the image."))),
      "image/png",
    );
  });
}

export function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

const VIDEO_TYPES = ["video/webm;codecs=vp9", "video/webm;codecs=vp8", "video/webm", "video/mp4"];

export function videoSupported(): boolean {
  return (
    typeof MediaRecorder !== "undefined" &&
    typeof HTMLCanvasElement.prototype.captureStream === "function" &&
    VIDEO_TYPES.some((t) => MediaRecorder.isTypeSupported(t))
  );
}

/**
 * Records frames drawn by `draw(elapsedMs)` into a video file.
 * The canvas must already be sized. Browsers cannot record transparent video,
 * so draw an opaque background (such as chroma green) for video.
 */
export function recordCanvasVideo(
  canvas: HTMLCanvasElement,
  draw: (elapsedMs: number) => void,
  opts: { durationMs: number; fps: number },
): Promise<{ blob: Blob; extension: string }> {
  if (!videoSupported()) {
    return Promise.reject(
      new Error("Video export is not supported in this browser. Try Chrome, Edge, Firefox or Safari."),
    );
  }
  const mimeType = VIDEO_TYPES.find((t) => MediaRecorder.isTypeSupported(t)) as string;
  const stream = canvas.captureStream(opts.fps);
  const recorder = new MediaRecorder(stream, { mimeType, videoBitsPerSecond: 8_000_000 });
  const chunks: Blob[] = [];
  recorder.ondataavailable = (e) => {
    if (e.data.size > 0) chunks.push(e.data);
  };

  return new Promise((resolve, reject) => {
    recorder.onerror = () => reject(new Error("Recording failed."));
    recorder.onstop = () => {
      stream.getTracks().forEach((t) => t.stop());
      const type = recorder.mimeType || mimeType;
      resolve({
        blob: new Blob(chunks, { type }),
        extension: type.includes("mp4") ? "mp4" : "webm",
      });
    };

    recorder.start(200);
    const start = performance.now();
    draw(0);
    const timer = window.setInterval(() => {
      const elapsed = Math.min(performance.now() - start, opts.durationMs);
      draw(elapsed);
      if (elapsed >= opts.durationMs) {
        window.clearInterval(timer);
        window.setTimeout(() => recorder.stop(), 150);
      }
    }, 1000 / opts.fps);
  });
}

export { ctxOf };
