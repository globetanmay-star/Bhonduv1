import { useMemo, useState } from "react";
import { CATEGORIES, TOOLS } from "../tools/registry";

export function Home() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All");

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return TOOLS.filter(
      (t) =>
        (category === "All" || t.category === category) &&
        `${t.name} ${t.description} ${t.category}`.toLowerCase().includes(q),
    );
  }, [query, category]);

  const scrollToTools = () => {
    document.getElementById("tools")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <>
      <section className="hero">
        <div>
          <p className="eyebrow">Tiny tools for big visuals</p>
          <h1>Make the visual. Skip the editor.</h1>
          <p className="lede">
            bhondu is a set of small browser tools for social posts: message mockups, username tags,
            stamps and pixel effects. Add your input, adjust a few controls, and download a PNG.
          </p>
          <div className="hero-actions">
            <a className="button primary" href={`#/tools/${TOOLS[0].slug}`}>
              Start with {TOOLS[0].name}
            </a>
            <button className="button" type="button" onClick={scrollToTools}>
              Browse tools
            </button>
          </div>
        </div>
        <div className="hero-art" aria-hidden="true">
          <p className="bubble in">Are you free later?</p>
          <p className="bubble out">Yes! Let's meet at 7.</p>
          <span className="tag-demo">@bhondu ✓</span>
        </div>
      </section>

      <section id="tools" className="section" aria-labelledby="tools-heading">
        <h2 id="tools-heading">Tools</h2>
        <div className="toolbar">
          <label className="search">
            <span className="visually-hidden">Search tools</span>
            <input
              type="search"
              placeholder="Search tools"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </label>
          <div className="chips" role="group" aria-label="Filter by category">
            {CATEGORIES.map((c) => (
              <button
                key={c}
                type="button"
                className="chip"
                aria-pressed={c === category}
                onClick={() => setCategory(c)}
              >
                {c}
              </button>
            ))}
          </div>
        </div>
        <div className="tool-grid">
          {visible.map((t) => (
            <a key={t.slug} className="tool-card" href={`#/tools/${t.slug}`}>
              <span className="tool-category">{t.category}</span>
              <h3>{t.name}</h3>
              <p>{t.description}</p>
              <span className="tool-open">Open →</span>
            </a>
          ))}
          {visible.length === 0 && <p className="muted">No tools match “{query}”.</p>}
        </div>
      </section>

      <section className="section" aria-labelledby="how-heading">
        <h2 id="how-heading">How it works</h2>
        <ol className="steps-list">
          <li>
            <h3>1. Add your input</h3>
            <p>Type text or choose an image from your device.</p>
          </li>
          <li>
            <h3>2. Adjust</h3>
            <p>Pick a style and tweak the controls. The preview updates as you go.</p>
          </li>
          <li>
            <h3>3. Export</h3>
            <p>Download a PNG at the size shown in the preview.</p>
          </li>
        </ol>
      </section>
    </>
  );
}
