import { useEffect, useState, type ReactNode } from "react";
import { Layout } from "./components/Layout";
import { Home } from "./pages/Home";
import { TOOLS } from "./tools/registry";

function currentPath(): string {
  return window.location.hash.replace(/^#/, "") || "/";
}

function NotFound() {
  return (
    <div className="section">
      <h1>Page not found</h1>
      <p className="muted">
        <a href="#/">Back to bhondu home</a>
      </p>
    </div>
  );
}

export default function App() {
  const [path, setPath] = useState(currentPath);

  useEffect(() => {
    const onChange = () => setPath(currentPath());
    window.addEventListener("hashchange", onChange);
    return () => window.removeEventListener("hashchange", onChange);
  }, []);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [path]);

  const match = path.match(/^\/tools\/([a-z-]+)$/);
  const tool = match ? TOOLS.find((t) => t.slug === match[1]) : undefined;

  let page: ReactNode;
  if (path === "/") {
    page = <Home />;
  } else if (tool) {
    const ToolComponent = tool.component;
    page = <ToolComponent />;
  } else {
    page = <NotFound />;
  }

  return <Layout path={path}>{page}</Layout>;
}
