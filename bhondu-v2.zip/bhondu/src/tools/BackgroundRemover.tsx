import { useState } from "react";
import { removeBackground } from "@imgly/background-removal";
import { ImageInput } from "../components/ImageInput";
import { Segmented } from "../components/Segmented";
import { ToolShell } from "../components/ToolShell";
import { ctxOf } from "../lib/canvas";
import { EXPORT_SIZE_OPTIONS, canvasToBlob, downloadBlob, fitTo, type ExportSize } from "../lib/export";

export default function BackgroundRemover() {
  const [file, setFile] = useState<File | null>(null);
  const [originalUrl, setOriginalUrl] = useState<string | null>(null);
  const [resultBlob, setResultBlob] = useState<Blob | null>(null);
  const [resultUrl, setResultUrl] = useState<string | null>(null);
  const [size, setSize] = useState<ExportSize>("hd");
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFile = (_img: HTMLImageElement, picked: File) => {
    setFile(picked);
    setOriginalUrl(URL.createObjectURL(picked));
    setResultBlob(null);
    setResultUrl(null);
    setError(null);
  };

  const removeBg = async () => {
    if (!file) return;
    setBusy(true);
    setError(null);
    setResultBlob(null);
    setStatus("Removing background. The first run downloads a model, so it can take a minute.");
    try {
      const blob = await removeBackground(file);
      setResultBlob(blob);
      setResultUrl(URL.createObjectURL(blob));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Background removal failed.");
    } finally {
      setBusy(false);
      setStatus(null);
    }
  };

  const exportPng = async () => {
    if (!resultBlob) return;
    setBusy(true);
    setError(null);
    try {
      const bitmap = await createImageBitmap(resultBlob);
      const { w, h } = fitTo(size, bitmap.width, bitmap.height);
      const canvas = document.createElement("canvas");
      canvas.width = w;
      canvas.height = h;
      const ctx = ctxOf(canvas);
      ctx.imageSmoothingQuality = "high";
      ctx.drawImage(bitmap, 0, 0, w, h);
      bitmap.close();
      downloadBlob(await canvasToBlob(canvas), `bhondu-cutout-${size}.png`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Export failed.");
    } finally {
      setBusy(false);
    }
  };

  const reset = () => {
    setFile(null);
    setOriginalUrl(null);
    setResultBlob(null);
    setResultUrl(null);
    setSize("hd");
    setError(null);
  };

  return (
    <ToolShell
      title="Background Remover"
      intro="Lift the subject out of a photo. The model runs in your browser, and the result is a transparent PNG."
      controls={
        <>
          <ImageInput label="Choose image" onLoad={handleFile} onError={setError} />

          <button className="button" type="button" onClick={removeBg} disabled={!file || busy}>
            Remove background
          </button>

          {status && <p className="muted" role="status">{status}</p>}
          {error && <p className="error" role="alert">{error}</p>}

          <Segmented legend="Export size" options={EXPORT_SIZE_OPTIONS} value={size} onChange={setSize} />
          <p className="muted">Sizes above the cutout's original resolution are upscaled, so they can look soft.</p>

          <div className="actions">
            <button className="button primary" type="button" onClick={exportPng} disabled={!resultBlob || busy}>
              Download PNG
            </button>
            <button className="button" type="button" onClick={reset} disabled={busy}>
              Reset
            </button>
          </div>
        </>
      }
      preview={
        resultUrl ? (
          <div className="checker" style={{ width: "100%", display: "grid", placeItems: "center" }}>
            <img className="output" src={resultUrl} alt="Photo with background removed" />
          </div>
        ) : originalUrl ? (
          <div style={{ width: "100%", display: "grid", placeItems: "center", gap: 12 }}>
            <img className="output" src={originalUrl} alt="Original photo" />
            <p className="placeholder">Press Remove background to see the result.</p>
          </div>
        ) : (
          <p className="placeholder">Choose an image to get started.</p>
        )
      }
    />
  );
}
