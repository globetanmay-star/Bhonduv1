import { useEffect, useRef, useState } from "react";
import { ImageInput } from "../components/ImageInput";
import { Segmented } from "../components/Segmented";
import { ToolShell } from "../components/ToolShell";
import { setupCanvas } from "../lib/canvas";
import { EXPORT_SIZE_OPTIONS, canvasToBlob, downloadBlob, scaleFor, type ExportSize } from "../lib/export";

type Shape = "square" | "vertical" | "horizontal" | "circle";

const STAMP_SHAPES: Record<Shape, { label: string; w: number; h: number }> = {
  square: { label: "Square", w: 1000, h: 1000 },
  vertical: { label: "Vertical", w: 800, h: 1000 },
  horizontal: { label: "Horizontal", w: 1000, h: 800 },
  circle: { label: "Circle", w: 1000, h: 1000 },
};

const SHAPE_OPTIONS: { value: Shape; label: string }[] = (
  Object.keys(STAMP_SHAPES) as Shape[]
).map((id) => ({ value: id, label: STAMP_SHAPES[id].label }));

const DEFAULT_PAPER = "#f7f1e1";
const MARGIN = 70;
const HOLE_RADIUS = 14;
const HOLE_SPACING = 40;
const LOGICAL_LONG_SIDE = 1000;

/** Outline of the stamp (inset = 0) or of the picture window (inset = MARGIN). */
function shapePath(ctx: CanvasRenderingContext2D, shape: Shape, w: number, h: number, inset: number) {
  ctx.beginPath();
  if (shape === "circle") {
    ctx.arc(w / 2, h / 2, w / 2 - inset, 0, Math.PI * 2);
  } else {
    ctx.rect(inset, inset, w - inset * 2, h - inset * 2);
  }
}

/** Cuts small holes along the outer edge to mimic a perforated stamp. */
function perforate(ctx: CanvasRenderingContext2D, shape: Shape, w: number, h: number) {
  const hole = (x: number, y: number) => {
    ctx.beginPath();
    ctx.arc(x, y, HOLE_RADIUS, 0, Math.PI * 2);
    ctx.fill();
  };

  ctx.save();
  ctx.globalCompositeOperation = "destination-out";
  ctx.fillStyle = "#000";

  if (shape === "circle") {
    const r = w / 2;
    const count = Math.round((2 * Math.PI * r) / HOLE_SPACING);
    for (let i = 0; i < count; i++) {
      const a = (i / count) * Math.PI * 2;
      hole(w / 2 + r * Math.cos(a), h / 2 + r * Math.sin(a));
    }
  } else {
    const across = Math.floor(w / HOLE_SPACING);
    const down = Math.floor(h / HOLE_SPACING);
    for (let i = 0; i <= across; i++) {
      const x = (i / across) * w;
      hole(x, 0);
      hole(x, h);
    }
    for (let j = 0; j <= down; j++) {
      const y = (j / down) * h;
      hole(0, y);
      hole(w, y);
    }
  }

  ctx.restore();
}

/** Draws the stamp into a canvas at the given scale (1 for preview, larger for export). */
function renderStamp(canvas: HTMLCanvasElement, img: HTMLImageElement, shape: Shape, paper: string, scale: number) {
  const { w, h } = STAMP_SHAPES[shape];
  const ctx = setupCanvas(canvas, w, h, scale);

  ctx.fillStyle = paper;
  shapePath(ctx, shape, w, h, 0);
  ctx.fill();

  const winW = w - MARGIN * 2;
  const winH = h - MARGIN * 2;
  const s = Math.max(winW / img.width, winH / img.height);
  const dw = img.width * s;
  const dh = img.height * s;

  ctx.save();
  shapePath(ctx, shape, w, h, MARGIN);
  ctx.clip();
  ctx.drawImage(img, MARGIN + (winW - dw) / 2, MARGIN + (winH - dh) / 2, dw, dh);
  ctx.restore();

  perforate(ctx, shape, w, h);
}

export default function Stamp() {
  const previewRef = useRef<HTMLCanvasElement>(null);
  const [img, setImg] = useState<HTMLImageElement | null>(null);
  const [shape, setShape] = useState<Shape>("square");
  const [paper, setPaper] = useState(DEFAULT_PAPER);
  const [size, setSize] = useState<ExportSize>("hd");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (img && previewRef.current) renderStamp(previewRef.current, img, shape, paper, 1);
  }, [img, shape, paper]);

  const reset = () => {
    setShape("square");
    setPaper(DEFAULT_PAPER);
    setSize("hd");
    setError(null);
  };

  const exportPng = async () => {
    if (!img) return;
    setBusy(true);
    setError(null);
    try {
      const canvas = document.createElement("canvas");
      renderStamp(canvas, img, shape, paper, scaleFor(size, LOGICAL_LONG_SIDE));
      downloadBlob(await canvasToBlob(canvas), `bhondu-stamp-${size}.png`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Export failed.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <ToolShell
      title="Stamp"
      intro="Choose a photo, pick a shape and paper colour, then download a transparent stamp."
      controls={
        <>
          <ImageInput
            label="Choose image"
            onLoad={(loaded) => {
              setImg(loaded);
              setError(null);
            }}
            onError={setError}
          />

          <Segmented legend="Shape" options={SHAPE_OPTIONS} value={shape} onChange={setShape} />

          <label className="field">
            <span>Paper colour</span>
            <input type="color" value={paper} onChange={(e) => setPaper(e.target.value)} />
          </label>

          <Segmented legend="Export size" options={EXPORT_SIZE_OPTIONS} value={size} onChange={setSize} />

          {busy && <p className="muted" role="status">Exporting. Please wait.</p>}
          {error && <p className="error" role="alert">{error}</p>}

          <div className="actions">
            <button className="button primary" type="button" onClick={exportPng} disabled={!img || busy}>
              Download PNG
            </button>
            <button className="button" type="button" onClick={reset} disabled={busy}>
              Reset
            </button>
          </div>
        </>
      }
      preview={
        img ? (
          <div className="checker" style={{ width: "100%", display: "grid", placeItems: "center" }}>
            <canvas ref={previewRef} className="output" aria-label="Stamp preview" />
          </div>
        ) : (
          <p className="placeholder">Choose an image to see the stamp here.</p>
        )
      }
    />
  );
}
