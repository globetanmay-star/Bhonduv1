import { useEffect, useRef, useState } from "react";
import { Segmented } from "../components/Segmented";
import { ToolShell } from "../components/ToolShell";
import { SANS_FONT, measureContext, roundRectPath, setupCanvas } from "../lib/canvas";
import { EXPORT_SIZE_OPTIONS, canvasToBlob, downloadBlob, scaleFor, type ExportSize } from "../lib/export";

const FONT_SIZE = 72;
const PILL_HEIGHT = 136;
const PILL_PAD_X = 48;
const BADGE = 56;
const GAP = 16;
const MARGIN = 32;
const MAX_USERNAME = 30;
const DEFAULT_USERNAME = "bhondu";

type Theme = "light" | "dark";

const THEME_OPTIONS: { value: Theme; label: string }[] = [
  { value: "light", label: "Light" },
  { value: "dark", label: "Dark" },
];

interface TagOptions {
  username: string;
  dark: boolean;
  verified: boolean;
}

interface TagLayout {
  label: string;
  font: string;
  textWidth: number;
  pillWidth: number;
  width: number;
  height: number;
}

/** Keeps only characters Instagram allows in usernames. */
function cleanUsername(raw: string): string {
  return raw.replace(/^@+/, "").replace(/[^a-zA-Z0-9._]/g, "").slice(0, MAX_USERNAME);
}

function layoutTag(o: TagOptions): TagLayout {
  const font = `600 ${FONT_SIZE}px ${SANS_FONT}`;
  const measure = measureContext();
  measure.font = font;
  const label = `@${o.username || "username"}`;
  const textWidth = Math.ceil(measure.measureText(label).width);
  const pillWidth = PILL_PAD_X * 2 + textWidth + (o.verified ? GAP + BADGE : 0);
  return {
    label,
    font,
    textWidth,
    pillWidth,
    width: pillWidth + MARGIN * 2,
    height: PILL_HEIGHT + MARGIN * 2,
  };
}

function paintTag(ctx: CanvasRenderingContext2D, L: TagLayout, o: TagOptions): void {
  ctx.clearRect(0, 0, L.width, L.height);
  const x = MARGIN;
  const y = MARGIN;
  const centerY = y + PILL_HEIGHT / 2;

  ctx.fillStyle = o.dark ? "#1c1c1e" : "#ffffff";
  roundRectPath(ctx, x, y, L.pillWidth, PILL_HEIGHT, PILL_HEIGHT / 2);
  ctx.fill();

  ctx.font = L.font;
  ctx.textBaseline = "middle";
  ctx.fillStyle = o.dark ? "#f5f5f7" : "#111111";
  ctx.fillText(L.label, x + PILL_PAD_X, centerY);

  if (o.verified) {
    const badgeX = x + PILL_PAD_X + L.textWidth + GAP + BADGE / 2;
    ctx.fillStyle = "#0a84ff";
    ctx.beginPath();
    ctx.arc(badgeX, centerY, BADGE / 2, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = "#ffffff";
    ctx.lineWidth = 6;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.beginPath();
    ctx.moveTo(badgeX - BADGE * 0.22, centerY + BADGE * 0.02);
    ctx.lineTo(badgeX - BADGE * 0.06, centerY + BADGE * 0.18);
    ctx.lineTo(badgeX + BADGE * 0.24, centerY - BADGE * 0.16);
    ctx.stroke();
  }
}

export default function SocialTag() {
  const previewRef = useRef<HTMLCanvasElement>(null);
  const [username, setUsername] = useState(DEFAULT_USERNAME);
  const [theme, setTheme] = useState<Theme>("light");
  const [verified, setVerified] = useState(true);
  const [size, setSize] = useState<ExportSize>("hd");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const options: TagOptions = { username, dark: theme === "dark", verified };

  useEffect(() => {
    const canvas = previewRef.current;
    if (!canvas) return;
    const o: TagOptions = { username, dark: theme === "dark", verified };
    const L = layoutTag(o);
    const ctx = setupCanvas(canvas, L.width, L.height, 1);
    paintTag(ctx, L, o);
  }, [username, theme, verified]);

  const reset = () => {
    setUsername(DEFAULT_USERNAME);
    setTheme("light");
    setVerified(true);
    setSize("hd");
    setError(null);
  };

  const exportPng = async () => {
    setBusy(true);
    setError(null);
    try {
      const L = layoutTag(options);
      const canvas = document.createElement("canvas");
      const ctx = setupCanvas(canvas, L.width, L.height, scaleFor(size, L.width));
      paintTag(ctx, L, options);
      downloadBlob(await canvasToBlob(canvas), `bhondu-tag-${username || "username"}-${size}.png`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Export failed.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <ToolShell
      title="Social Tag"
      intro="Enter a username to get a clean tag. Downloads have a transparent background."
      controls={
        <>
          <label className="field">
            <span>Username</span>
            <input
              type="text"
              value={username}
              placeholder="username"
              onChange={(e) => setUsername(cleanUsername(e.target.value))}
              autoComplete="off"
            />
          </label>

          <Segmented legend="Theme" options={THEME_OPTIONS} value={theme} onChange={setTheme} />

          <label className="check">
            <input type="checkbox" checked={verified} onChange={(e) => setVerified(e.target.checked)} />
            Verified badge
          </label>

          <Segmented legend="Export size" options={EXPORT_SIZE_OPTIONS} value={size} onChange={setSize} />

          {busy && <p className="muted" role="status">Exporting. Please wait.</p>}
          {error && <p className="error" role="alert">{error}</p>}

          <div className="actions">
            <button className="button primary" type="button" onClick={exportPng} disabled={busy}>
              Download PNG
            </button>
            <button className="button" type="button" onClick={reset} disabled={busy}>
              Reset
            </button>
          </div>
        </>
      }
      preview={
        <div className="checker" style={{ width: "100%", display: "grid", placeItems: "center" }}>
          <canvas ref={previewRef} className="output" aria-label="Social tag preview" />
        </div>
      }
    />
  );
}
