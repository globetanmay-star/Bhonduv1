import type { ComponentType } from "react";
import TextMockup from "./TextMockup";
import SocialTag from "./SocialTag";
import Stamp from "./Stamp";
import PixelEffect from "./PixelEffect";
import BackgroundRemover from "./BackgroundRemover";

export interface ToolDef {
  slug: string;
  name: string;
  description: string;
  category: string;
  component: ComponentType;
}

/** Add a new tool here: create its component in src/tools and register it. */
export const TOOLS: ToolDef[] = [
  {
    slug: "text-mockup",
    name: "Text Mockup",
    category: "Text",
    description: "Message bubbles in chat styles. Export a transparent PNG or an animated video.",
    component: TextMockup,
  },
  {
    slug: "social-tag",
    name: "Social Tag",
    category: "Social",
    description: "An Instagram-style username tag with an optional verified badge.",
    component: SocialTag,
  },
  {
    slug: "stamp",
    name: "Stamp",
    category: "Image",
    description: "Turn a photo into a postage stamp with a perforated edge.",
    component: Stamp,
  },
  {
    slug: "pixel-effect",
    name: "Pixel Effect",
    category: "Image",
    description: "Pixelate a photo, then export a PNG or a reveal video at HD, 2K or 4K.",
    component: PixelEffect,
  },
  {
    slug: "background-remover",
    name: "Background Remover",
    category: "Image",
    description: "Lift the subject from a photo into a transparent PNG. Runs in your browser.",
    component: BackgroundRemover,
  },
];

export const CATEGORIES = ["All", ...Array.from(new Set(TOOLS.map((t) => t.category)))];
