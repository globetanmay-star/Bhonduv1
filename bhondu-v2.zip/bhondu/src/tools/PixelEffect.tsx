import { useEffect, useRef, useState } from "react";
import { ImageInput } from "../components/ImageInput";
import { Segmented } from "../components/Segmented";
import { ToolShell } from "../components/ToolShell";
import { ctxOf } from "../lib/canvas";
import {
  EXPORT_SIZE_OPTIONS,
  canvasToBlob,
  downloadBlob,
  fitTo,
  longSideOf,
  recordCanvasVideo,
  videoSupported,
  type ExportSize,
} from "../lib/export";

type Format = "png" | "video";

const FORMAT_OPTIONS: { value: Format; label: string }[] = [
  { value: "png", label: "PNG" },
  { value: "video", label: "Video" },
];

/** Block size slider is defined against HD so the look stays the same at every export size. */
const REFERENCE_LONG_SIDE = 1080;
const DEFAULT_PIXEL = 16;
const VIDEO_MS = 3000;
const VIDEO_FPS = 30;
const REVEAL_MS = 2000;

function blockPx(pixel: number, longSide: number): number {
  return pixel * (longSide / REFERENCE_LONG_SIDE);
}

/** Smoothly shrinks the block size from chunky to the final size during the reveal. */
function revealBlock(elapsed: number, finalBlock: number, startBlock: number): number {
  const t = Math.max(0, Math.min(1, elapsed / REVEAL_MS));
  const eased = 1 - Math.pow(1 - t, 3);
  const logStart = Math.log(startBlock);
  const logEnd = Math.log(finalBlock);
  return Math.exp(logStart + (logEnd - logStart) * eased);
}

/** Shrinks the image to a grid of blocks, then scales back up without smoothing. */
function paintPixelated(ctx: CanvasRenderingContext2D, img: HTMLImageElement, w: number, h: number, block: number) {
  const bw = Math.max(1, Math.round(w / block));
  const bh = Math.max(1, Math.round(h / block));

  const small = document.createElement("canvas");
  small.width = bw;
  small.height = bh;
  ctxOf(small).drawImage(img, 0, 0, bw, bh);

  ctx.imageSmoothingEnabled = false;
  ctx.drawImage(small, 0, 0, w, h);
}

export default function PixelEffect() {
  const beforeRef = useRef<HTMLCanvasElement>(null);
  const afterRef = useRef<HTMLCanvasElement>(null);
  const [img, setImg] = useState<HTMLImageElement | null>(null);
  const [pixel, setPixel] = useState(DEFAULT_PIXEL);
  const [format, setFormat] = useState<Format>("png");
  const [size, setSize] = useState<ExportSize>("hd");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!img || !beforeRef.current) return;
    const { w, h } = fitTo("hd", img.width, img.height);
    const canvas = beforeRef.current;
    canvas.width = w;
    canvas.height = h;
    ctxOf(canvas).drawImage(img, 0, 0, w, h);
  }, [img]);

  useEffect(() => {
    if (!img || !afterRef.current) return;
    const { w, h } = fitTo("hd", img.width, img.height);
    const canvas = afterRef.current;
    canvas.width = w;
    canvas.height = h;
    paintPixelated(ctxOf(canvas), img, w, h, blockPx(pixel, REFERENCE_LONG_SIDE));
  }, [img, pixel]);

  const reset = () => {
    setPixel(DEFAULT_PIXEL);
    setFormat("png");
    setSize("hd");
    setError(null);
  };

  const exportFile = async () => {
    if (!img) return;
    setBusy(true);
    setError(null);
    try {
      const { w, h } = fitTo(size, img.width, img.height);
      const finalBlock = blockPx(pixel, longSideOf(size));
      const canvas = document.createElement("canvas");
      canvas.width = w;
      canvas.height = h;
      const ctx = ctxOf(canvas);

      if (format === "png") {
        paintPixelated(ctx, img, w, h, finalBlock);
        downloadBlob(await canvasToBlob(canvas), `bhondu-pixel-${size}.png`);
      } else {
        // Chunky blocks resolve into the chosen block size over the first two seconds.
        const startBlock = Math.max(w, h) / 4;
        const { blob, extension } = await recordCanvasVideo(
          canvas,
          (elapsed) => {
            const b = revealBlock(elapsed, finalBlock, startBlock);
            paintPixelated(ctx, img, w, h, b);
          },
          { durationMs: VIDEO_MS, fps: VIDEO_FPS },
        );
        downloadBlob(blob, `bhondu-pixel-${size}.${extension}`);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Export failed.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <ToolShell
      title="Pixel Effect"
      intro="Choose a photo and set the block size. Download a PNG, or a short video of the pixel reveal."
      controls={
        <>
          <ImageInput
            label="Choose image"
            onLoad={(loaded) => {
              setImg(loaded);
              setError(null);
            }}
            onError={setError}
          />

          <label className="field">
            <span>Block size: {pixel}px</span>
            <input type="range" min={2} max={80} value={pixel} onChange={(e) => setPixel(Number(e.target.value))} />
          </label>

          <Segmented legend="Format" options={FORMAT_OPTIONS} value={format} onChange={setFormat} />
          <Segmented legend="Export size" options={EXPORT_SIZE_OPTIONS} value={size} onChange={setSize} />

          {format === "video" && (
            <p className="muted">Video: {VIDEO_MS / 1000} seconds. Blocks resolve into the chosen size.</p>
          )}
          {format === "video" && !videoSupported() && (
            <p className="error" role="alert">Video export is not supported in this browser.</p>
          )}
          <p className="muted">Sizes above the original photo are upscaled. Blocks stay sharp.</p>
          {busy && <p className="muted" role="status">Exporting. Please wait.</p>}
          {error && <p className="error" role="alert">{error}</p>}

          <div className="actions">
            <button className="button primary" type="button" onClick={exportFile} disabled={!img || busy}>
              {format === "png" ? "Download PNG" : "Download video"}
            </button>
            <button className="button" type="button" onClick={reset} disabled={busy}>
              Reset
            </button>
          </div>
        </>
      }
      preview={
        img ? (
          <div className="pair">
            <figure>
              <canvas ref={beforeRef} className="output" aria-label="Original photo" />
              <figcaption>Before</figcaption>
            </figure>
            <figure>
              <canvas ref={afterRef} className="output" aria-label="Pixelated result" />
              <figcaption>After</figcaption>
            </figure>
          </div>
        ) : (
          <p className="placeholder">Choose an image to see the before and after here.</p>
        )
      }
    />
  );
}
