import { useEffect, useRef, useState } from "react";
import { Segmented } from "../components/Segmented";
import { ToolShell } from "../components/ToolShell";
import { SANS_FONT, measureContext, roundRectPath, setupCanvas, wrapLines } from "../lib/canvas";
import {
  EXPORT_SIZE_OPTIONS,
  canvasToBlob,
  downloadBlob,
  recordCanvasVideo,
  scaleFor,
  videoSupported,
  type ExportSize,
} from "../lib/export";

interface Preset {
  id: string;
  label: string;
  bubble: string;
  text: string;
  align: "left" | "right";
}

type Background = "transparent" | "white" | "dark" | "green";
type Format = "png" | "video";

const PRESETS: Preset[] = [
  { id: "sent", label: "Sent (blue)", bubble: "#0b84fe", text: "#ffffff", align: "right" },
  { id: "received", label: "Received (grey)", bubble: "#e9e9eb", text: "#111111", align: "left" },
  { id: "dark", label: "Dark mode", bubble: "#2c2c2e", text: "#f2f2f7", align: "left" },
];

const BACKGROUND_OPTIONS: { value: Background; label: string }[] = [
  { value: "transparent", label: "Transparent" },
  { value: "white", label: "White" },
  { value: "dark", label: "Black" },
  { value: "green", label: "Green key" },
];

const BG_COLOR: Record<Exclude<Background, "transparent">, string> = {
  white: "#ffffff",
  dark: "#000000",
  green: "#00ff00",
};

const FORMAT_OPTIONS: { value: Format; label: string }[] = [
  { value: "png", label: "PNG" },
  { value: "video", label: "Video" },
];

const DEFAULT_TEXT = "Hey, are you free later?\nLet's meet at 7.";
const DEFAULT_FONT_SIZE = 44;
const WIDTH = 1080;
const PAD = 80;
const BUBBLE_PAD_X = 40;
const BUBBLE_PAD_Y = 28;
const BUBBLE_RADIUS = 42;
const MAX_TEXT_WIDTH = 720;

const VIDEO_MS = 3000;
const VIDEO_FPS = 30;
const BUBBLE_IN_MS = 500;
const TEXT_START_MS = 500;
const TEXT_END_MS = 2500;

interface MockupState {
  text: string;
  preset: Preset;
  fontSize: number;
  background: Background;
}

interface Layout {
  font: string;
  lines: string[];
  lineHeight: number;
  bubbleX: number;
  bubbleY: number;
  bubbleW: number;
  bubbleH: number;
  width: number;
  height: number;
}

function layoutMockup(s: MockupState): Layout {
  const font = `${s.fontSize}px ${SANS_FONT}`;
  const measure = measureContext();
  measure.font = font;

  const lines = wrapLines(measure, s.text, MAX_TEXT_WIDTH);
  const lineHeight = Math.round(s.fontSize * 1.3);
  const longest = Math.max(...lines.map((l) => measure.measureText(l).width));
  const bubbleW = Math.min(Math.ceil(longest) + BUBBLE_PAD_X * 2, WIDTH - PAD * 2);
  const bubbleH = lines.length * lineHeight + BUBBLE_PAD_Y * 2;

  return {
    font,
    lines,
    lineHeight,
    bubbleX: s.preset.align === "right" ? WIDTH - PAD - bubbleW : PAD,
    bubbleY: PAD,
    bubbleW,
    bubbleH,
    width: WIDTH,
    height: bubbleH + PAD * 2,
  };
}

function clamp01(n: number): number {
  return Math.max(0, Math.min(1, n));
}

function easeOutCubic(t: number): number {
  return 1 - Math.pow(1 - t, 3);
}

/**
 * Paints one frame. elapsed = null draws the finished mockup.
 * Otherwise the bubble pops in, then the text types out.
 */
function paintMockup(
  ctx: CanvasRenderingContext2D,
  L: Layout,
  s: MockupState,
  elapsed: number | null,
  fill: string | null,
): void {
  ctx.clearRect(0, 0, L.width, L.height);
  if (fill) {
    ctx.fillStyle = fill;
    ctx.fillRect(0, 0, L.width, L.height);
  }

  const bubbleT = elapsed === null ? 1 : clamp01(elapsed / BUBBLE_IN_MS);
  if (bubbleT <= 0) return;
  const textT =
    elapsed === null ? 1 : clamp01((elapsed - TEXT_START_MS) / (TEXT_END_MS - TEXT_START_MS));

  const eased = easeOutCubic(bubbleT);
  const cx = L.bubbleX + L.bubbleW / 2;
  const cy = L.bubbleY + L.bubbleH / 2;

  ctx.save();
  ctx.globalAlpha = eased;
  ctx.translate(cx, cy);
  ctx.scale(0.8 + 0.2 * eased, 0.8 + 0.2 * eased);
  ctx.translate(-cx, -cy);

  ctx.fillStyle = s.preset.bubble;
  roundRectPath(ctx, L.bubbleX, L.bubbleY, L.bubbleW, L.bubbleH, BUBBLE_RADIUS);
  ctx.fill();

  ctx.font = L.font;
  ctx.textBaseline = "top";
  ctx.fillStyle = s.preset.text;

  const total = L.lines.reduce((sum, l) => sum + l.length, 0);
  let remaining = Math.floor(total * textT);
  L.lines.forEach((line, i) => {
    if (remaining <= 0) return;
    ctx.fillText(line.slice(0, remaining), L.bubbleX + BUBBLE_PAD_X, L.bubbleY + BUBBLE_PAD_Y + i * L.lineHeight);
    remaining -= line.length;
  });

  ctx.restore();
}

function fillFor(bg: Background): string | null {
  return bg === "transparent" ? null : BG_COLOR[bg];
}

export default function TextMockup() {
  const previewRef = useRef<HTMLCanvasElement>(null);
  const [text, setText] = useState(DEFAULT_TEXT);
  const [presetId, setPresetId] = useState(PRESETS[0].id);
  const [fontSize, setFontSize] = useState(DEFAULT_FONT_SIZE);
  const [background, setBackground] = useState<Background>("transparent");
  const [format, setFormat] = useState<Format>("png");
  const [size, setSize] = useState<ExportSize>("hd");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const preset = PRESETS.find((p) => p.id === presetId) ?? PRESETS[0];

  useEffect(() => {
    const canvas = previewRef.current;
    if (!canvas) return;
    const s: MockupState = { text: text.trim() || "Type a message", preset, fontSize, background };
    const L = layoutMockup(s);
    const ctx = setupCanvas(canvas, L.width, L.height, 1);
    paintMockup(ctx, L, s, null, fillFor(background));
  }, [text, preset, fontSize, background]);

  const reset = () => {
    setText(DEFAULT_TEXT);
    setPresetId(PRESETS[0].id);
    setFontSize(DEFAULT_FONT_SIZE);
    setBackground("transparent");
    setFormat("png");
    setSize("hd");
    setError(null);
  };

  const exportFile = async () => {
    setBusy(true);
    setError(null);
    try {
      const s: MockupState = { text: text.trim() || "Type a message", preset, fontSize, background };
      const L = layoutMockup(s);
      const canvas = document.createElement("canvas");
      const ctx = setupCanvas(canvas, L.width, L.height, scaleFor(size, L.width));

      if (format === "png") {
        paintMockup(ctx, L, s, null, fillFor(background));
        downloadBlob(await canvasToBlob(canvas), `bhondu-message-${size}.png`);
      } else {
        // Video cannot be transparent, so a transparent choice falls back to green for keying.
        const videoFill = fillFor(background === "transparent" ? "green" : background);
        const { blob, extension } = await recordCanvasVideo(
          canvas,
          (elapsed) => paintMockup(ctx, L, s, elapsed, videoFill),
          { durationMs: VIDEO_MS, fps: VIDEO_FPS },
        );
        downloadBlob(blob, `bhondu-message-${size}.${extension}`);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Export failed.");
    } finally {
      setBusy(false);
    }
  };

  const videoNote =
    format === "video" && background === "transparent"
      ? "Video cannot be transparent. The green key colour will be used instead."
      : null;

  return (
    <ToolShell
      title="Text Mockup"
      intro="Type a message, pick a bubble style, then download a PNG or an animated video."
      controls={
        <>
          <label className="field">
            <span>Message</span>
            <textarea rows={4} maxLength={400} value={text} onChange={(e) => setText(e.target.value)} />
          </label>

          <Segmented
            legend="Style"
            options={PRESETS.map((p) => ({ value: p.id, label: p.label }))}
            value={presetId}
            onChange={setPresetId}
          />

          <label className="field">
            <span>Font size: {fontSize}px</span>
            <input
              type="range"
              min={24}
              max={80}
              value={fontSize}
              onChange={(e) => setFontSize(Number(e.target.value))}
            />
          </label>

          <Segmented legend="Background" options={BACKGROUND_OPTIONS} value={background} onChange={setBackground} />
          <Segmented legend="Format" options={FORMAT_OPTIONS} value={format} onChange={setFormat} />
          <Segmented legend="Export size" options={EXPORT_SIZE_OPTIONS} value={size} onChange={setSize} />

          {format === "video" && (
            <p className="muted">Video: {VIDEO_MS / 1000} seconds, the bubble pops in and the text types out.</p>
          )}
          {videoNote && <p className="muted">{videoNote}</p>}
          {format === "video" && !videoSupported() && (
            <p className="error" role="alert">Video export is not supported in this browser.</p>
          )}
          {busy && <p className="muted" role="status">Exporting. Please wait.</p>}
          {error && <p className="error" role="alert">{error}</p>}

          <div className="actions">
            <button className="button primary" type="button" onClick={exportFile} disabled={busy}>
              {format === "png" ? "Download PNG" : "Download video"}
            </button>
            <button className="button" type="button" onClick={reset} disabled={busy}>
              Reset
            </button>
          </div>
        </>
      }
      preview={
        <div
          className={background === "transparent" ? "checker" : ""}
          style={{ width: "100%", display: "grid", placeItems: "center" }}
        >
          <canvas ref={previewRef} className="output" aria-label="Text mockup preview" />
        </div>
      }
    />
  );
}
